package viewmodel.nhanVien.sanPham;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import viewmodel.defaultViewModel.ChiTietHoaDonViewModel;

public class HoaDon {
	 private int maHoaDon;
	    private int maNhanVien;
	    private Date thoiGian;
	    private int maVoucher;
	    private int dichVuPhatSinh;
	    private String ghiChu;
	    private List<Integer> lstMaBan;
	    private List<ChiTietHoaDonViewModel> lstChiTietHoaDonViewModels;
	    

}
