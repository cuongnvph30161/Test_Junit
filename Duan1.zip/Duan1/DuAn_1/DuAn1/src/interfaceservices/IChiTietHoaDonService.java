package interfaceservices;

import viewmodel.defaultViewModel.ChiTietHoaDonViewModel;

/**
 *
 * @author Doanh
 */
public interface IChiTietHoaDonService {
boolean insert(ChiTietHoaDonViewModel vmChiTietHoaDon);
}
