package interfaceservices;

import viewmodel.defaultViewModel.BanHoaDonViewModel;

/**
 *
 * @author Doanh
 */
public interface IBanHoaDonService {
    boolean insert(BanHoaDonViewModel vmBanHoaDon);
}
