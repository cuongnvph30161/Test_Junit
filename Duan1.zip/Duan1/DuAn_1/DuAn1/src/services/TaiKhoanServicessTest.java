package services;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaiKhoanServicessTest {

	@Test
	public void testInsertTaiKhoan() {
	   
	}

}
